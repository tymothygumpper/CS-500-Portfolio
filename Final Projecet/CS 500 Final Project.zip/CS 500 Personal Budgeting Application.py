import json
import matplotlib.pyplot as plt
from datetime import datetime

# Expense Class
class Expense:

    def __init__(self, amount: float, description: str, date: str) -> None:
        self.amount = amount
        self.description = description
        self.date = date


# Budget Category Class
class BudgetCategory:

    def __init__(self, name: str)-> None:
        self.name = name
        self.expenses = []

    def add_expense(self, amount: float, description: str, date: str)-> None:
        expense = Expense(amount, description, date)
        self.expenses.append(expense)

    def total_expenses(self)-> float:
        return sum(expense.amount for expense in self.expenses)



# Budget Manager Class
class BudgetManager:

    def __init__(self)-> None:
        self.income = 0.0
        self.savings_goal = 0.0
        self.categories = {}
        self.load_data()


    def set_income(self, amount: float)-> None:
        self.income = amount


    def set_savings_goal(self, amount: float)-> None:
        self.savings_goal = amount       


    def add_expense(self,category_name: str, amount: float, description: str, date: str)-> None:
        if category_name not in self.categories:
            self.categories[category_name] = BudgetCategory(category_name)

        self.categories[category_name].add_expense(amount, description, date)


    def total_expenses(self)-> float:
        return sum(category.total_expenses() for category in self.categories.values())
    


    def progress_toward_goal(self)-> float:
        current_savings = self.income - self.total_expenses()
        return current_savings


    def save_data(self)-> None:
        data = {
            "income": self.income,
            "savings_goal": self.savings_goal,
            "categories": {}
        }

        for name, category in self.categories.items():
            data["categories"][name] = []

            for expense in category.expenses:
                data["categories"][name].append({
                    "amount": expense.amount,
                    "description": expense.description,
                    "date": expense.date
                })
        

        with open("budget_data.json", "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4)




    def load_data(self)-> None:
        try:
            with open("budget_data.json", "r", encoding="utf-8") as file:
                data = json.load(file)

                self.income = data.get("income", 0.0)
                self.savings_goal = data.get("savings_goal", 0.0)

                for name, expenses in data.get("categories", {}).items():
                    category = BudgetCategory(name)

                    for expense_data in expenses:
                        expense = Expense(
                            expense_data["amount"],
                            expense_data["description"],
                            expense_data["date"]
                        )
                        category.expenses.append(expense)

                    self.categories[name] = category

        except FileNotFoundError:
            pass



    def visualize_expenses(self)-> None:
        if not self.categories:
            print("No expenses available to visualize.")
            return

        category_names = []
        category_totals = []

        for name, category in self.categories.items():
            category_names.append(name)
            category_totals.append(category.total_expenses())

        plt.bar(category_names, category_totals)
        plt.title("Expenses by Category")
        plt.xlabel("Category")
        plt.ylabel("Amount Spent ($)")
        plt.tight_layout()
        plt.show()





# Input Validation Functions

def get_valid_float(prompt: str)-> float:
    while True:
        try:
            value = float(input(prompt))

            if value < 0:
                print("Please enter a value greater than or equal to 0.")
                continue

            return value

        except ValueError:
            print("Invalid input. Please enter a number.")



 
def get_valid_date(prompt: str)-> str:
    while True:
        date_input = input(prompt)

        try:
            datetime.strptime(date_input, "%Y-%m-%d")
            return date_input

        except ValueError:
            print("Invalid date. Please use YYYY-MM-DD format.")




# Main Program
def main()-> None:
    manager = BudgetManager()
    
    print("Welcome to Personal Budgeting Application!")
    
    while True:
        print("\nMenu:")
        print("1. Set Income")
        print("2. Set Savings Goal")
        print("3. Add Expense")
        print("4. View Total Expenses")
        print("5. View Savings Progress")
        print("6. Visualize Expenses")
        print("7. Save & Exit")
        
        choice = input("Choose an option (1-7): ")

        if choice == '1':
            income = get_valid_float("Enter monthly income: $")
            manager.set_income(income)
            print(f"Income set to: ${income:.2f}")
            

        
        elif choice == '2':
            savings_goal = get_valid_float("Enter savings goal: $")
            manager.set_savings_goal(savings_goal)
            print(f"Savings goal set to: ${savings_goal:.2f}")

        
        elif choice == '3':
           category_name = input("Enter expense category: ")
           amount = get_valid_float("Enter expense amount: $")
           description = input("Enter expense description: ")
           date = get_valid_date ("Enter expense date (YYYY-MM-DD): ")

           manager.add_expense(category_name, amount, description, date)
           print(f"Added ${amount:.2f} expense to {category_name}.")

        
        elif choice == '4':
            total = manager.total_expenses()
            print(f"Total expenses: ${total:.2f}")

        
        elif choice == '5':
            current_savings = manager.progress_toward_goal()

            if current_savings >= manager.savings_goal:
                print("You are on track!")
                print(f"Current savings : ${current_savings:.2f}")
            else:
                amount_needed = manager.savings_goal - current_savings
                print(f"Current savings: ${current_savings:.2f}")
                print(f"You need ${amount_needed:.2f} to reach your goal.")


        elif choice == '6':
            manager.visualize_expenses()


        
        elif choice == '7':
            manager.save_data()
            print("Data saved successfully. Exiting the program.")
            break

        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

